from data.jobs import Jobs
from data import db_session
from data.user import User
from flask import Flask, render_template

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add_user(sess, surname, name, age, position, spec, address, email, pas):
    user = User()
    user.surname = surname
    user.name = name
    user.age = age
    user.position = position
    user.speciality = spec
    user.address = address
    user.email = email
    user.hashed_password = pas
    sess.add(user)
    sess.commit()


def add_job(sess, team_leader, job1, work_size, collab, fin):
    job = Jobs()
    job.team_leader = team_leader
    job.job = job1
    job.work_size = work_size
    job.collaborators = collab
    job.is_finished = fin
    sess.add(job)
    sess.commit()


@app.route('/')
def main_window():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template('main.html', jobs=jobs)


def main():
    db_session.global_init("db/mars_explorer.db")
    app.run()


if __name__ == '__main__':
    main()
