from data.jobs import Jobs
from data import db_session
from data.user import User
from flask import Flask, render_template, redirect, request
from login import LoginForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add_user(sess, surname, name, age, position, spec, address, email, pas):
    user = User()
    user.surname = surname
    user.name = name
    user.age = age
    user.position = position
    user.speciality = spec
    user.address = address
    user.email = email
    user.set_password(pas)
    sess.add(user)
    sess.commit()


def add_job(sess, team_leader, job1, work_size, collab, fin):
    job = Jobs()
    job.team_leader = team_leader
    job.job = job1
    job.work_size = work_size
    job.collaborators = collab
    job.is_finished = fin
    sess.add(job)
    sess.commit()


@app.route('/success')
def success():
    return render_template('base.html', title='Успешно')


@app.route('/register', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        form = LoginForm()
        return render_template('login.html', title='Регистрация', form=form)
    elif request.method == 'POST':
        db_sess = db_session.create_session()
        add_user(db_sess, request.form.get('surname'), request.form.get('name'), request.form.get('age'),
                 request.form.get('position'), request.form.get('speciality'), request.form.get('address'),
                 request.form.get('email'),
                 request.form.get('password'))
        return redirect('/success')


def main():
    db_session.global_init("db/mars_explorer.db")
    app.run()


if __name__ == '__main__':
    main()
